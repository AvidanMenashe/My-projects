
//Avidan Menashe
#pragma once
#include "C:\Program Files\Autodesk\Maya2022\include\maya\MPxCommand.h"
#include <unordered_set>
class topologyStatisticsCmd : public MPxCommand
{
public:
	topologyStatisticsCmd();
	virtual MStatus	doIt(const MArgList& argList);
	static void* creator();
	static MSyntax syntax();
	static MString commandName();
	virtual bool isUndoable() const;

private:
	void FindLoopInBoundaryEdges(MItMeshEdge& edge_it, std::unordered_set<int>& BoundaryEdgesSet, const int& set_first_indx);
	double CalcCurvature(const MFnMesh& meshFn, MDoubleArray& curvature);
	void FindConnectedComponents(MItMeshVertex& vertix_it, std::unordered_set<int>& VertixIndexSet, const int& set_first_indx);
};

