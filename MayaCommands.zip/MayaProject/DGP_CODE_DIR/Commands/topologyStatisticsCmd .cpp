
//Avidan Menashe
//this command works only on a triangular mesh and show the topological charactaristics of the mesh
//such as, the number of vertices, edges and faces.Also, euler number, the genus of the mesh, number of connected components and the number of boundaries.
#include "topologyStatisticsCmd.h"
#include "stdafx.h"
#include <string.h>

#include "Utils/STL_Macros.h"
#include "Utils/Maya_Macros.h"
#include "Utils/Maya_Utils.h"
#include "Utils/MatlabInterface.h"
#include "Utils/GMM_Macros.h"
#include "Utils/MatlabGMMDataExchange.h"
#include "Utils/Utilities.h"



topologyStatisticsCmd::topologyStatisticsCmd()
{

}

// This meathod returns a pointer to a new instance of the command.
void* topologyStatisticsCmd::creator()
{
	return new topologyStatisticsCmd;
}

// This method returns the name of the command.
MString topologyStatisticsCmd::commandName()
{
	return "topologyStatisticsCmd";
}

bool topologyStatisticsCmd::isUndoable() const
{
	return false;
}

MStatus	topologyStatisticsCmd::doIt(const MArgList& argList)
{
	MStatus stat = MS::kSuccess;

	// We copied the checks for the syntax from the command colorMeshVerticesCmd.
	MSyntax commandSyntax = syntax();
	MArgDatabase argData(commandSyntax, argList, &stat);
	MCHECKERROR(stat, "Wrong syntax for command " + commandName());

	MSelectionList objectsList;
	stat = argData.getObjects(objectsList);
	MCHECKERROR(stat, "Can't access object list");

	MObject object;
	stat = objectsList.getDependNode(0, object);
	MCHECKERROR(stat, "Can't access object");

	MObject meshObject;
	stat = Maya_Utils::getMe_a_Mesh(object, meshObject);
	MCHECKERROR(stat, "Object is not a mesh");

	MFnMesh meshFn(meshObject, &stat);
	MCHECKERROR(stat, "Can't access mesh");


	int numVerticesInMeshCreated = 0;
	int numPolygons = meshFn.numPolygons(&stat);

	MItMeshPolygon poly(meshObject);
	if (!poly.isPlanar(&stat) || poly.isLamina(&stat) || poly.isHoled(&stat))
	{
		MCHECKERROR(MS::kFailure, "The given polygon shape is either self intersecting, holed or non-planar which are not supported");
	}

	//Check if the mesh is a triangle mesh
	unsigned int temp;
	for (int i = 0; i < numPolygons; i++)
	{
		temp = poly.polygonVertexCount();
		if (3 != temp)
			MCHECKERROR(MS::kFailure, "this is not a triangle mesh!");
		poly.next();
	}

	//Now, we create an Mstring to build the statistics of the current mesh object.
	MString statistical_results = MString("\n");

	//first row of the statistics table.
	statistical_results += MString("Mesh name: ") + meshFn.name() + MString("\n");

	//second row of the statistics table : check if the mesh is a triangle mesh
	statistical_results += MString("Is triangle mesh: ");

	//Define two MIntArray to store the number of vertices of each polygon and there indexes
	MIntArray polygonVerticesCounts; //--> for the number of vertices of each polygon
	MIntArray polygonVerticesIndxConnects; //--> for the indexes of the vertices of each polygon

	// Define a flag to check if the mesh is a triangle mesh.
	bool isTriangleMesh = true;

	//get the number of polygons of the mesh.
	if (meshFn.numPolygons() > 0)
	{
		//get the number of vertices of each polygon and there indexes
		meshFn.getVertices(polygonVerticesCounts, polygonVerticesIndxConnects);

		//Iterate over all mesh polygons and check vertex count.
		for (int i = 0; i < polygonVerticesCounts.length(); i++)
		{
			//if the number of vertices of a polygon is not equal to 3, the mesh is not a triangle mesh.
			if (polygonVerticesCounts[i] != 3)
			{
				isTriangleMesh = false;
				break;
			}
		}

		//Check the flag and print the result.
		if (isTriangleMesh)
		{
			statistical_results += MString("Yes") + MString("\n");
		}
		else
		{
			statistical_results += MString("No") + MString("\n");
		}
	}
	else
	{
		MCHECKERROR(MS::kFailure, "This is an empty mesh! it has no polygons!");
	}

	//third row of the statistics table : number of vertices
	const int Vertices = meshFn.numVertices();
	statistical_results += MString("Number of vertices: ") + Vertices + MString("\n");

	//fourth row of the statistics table : number of faces
	const int Faces = meshFn.numPolygons();
	statistical_results += MString("Number of faces: ") + Faces + MString("\n");

	//fifth row of the statistics table : number of edges
	const int Edges = meshFn.numEdges();
	statistical_results += MString("Number of edges: ") + Edges + MString("\n");

	//sixth row of the statistics table : Genus (formula from slides)
	const int Genus = 1 - (Vertices - Edges + Faces) / 2;
	statistical_results += MString("Genus: ") + Genus + MString("\n");

	//seventh row of the statistics table : Number of connected components
	// iterate over the set of vertices and find all the connected components
	// create a vertex iterator
	MItMeshVertex vertex_it(meshFn.object());
	if (stat != MS::kSuccess)
	{
		MCHECKERROR(MS::kFailure, "Can't create vertex iterator");
	}
	// create a set to save all the vertices
	std::unordered_set<int> vertcises;
	//iterate over all vertices and add them to the set
	while (!vertex_it.isDone())
	{
		vertcises.insert(vertex_it.index());
		vertex_it.next();
	}
	//create a variable to save the number of connected components
	int connectedComponents = 0;
	while (!vertcises.empty())
	{
		//get first element of the set
		const int first_index = *vertcises.begin();
		//call the FindConnectedComponent method to find the 
		// connected component of the first vertex
		FindConnectedComponents(vertex_it, vertcises, first_index);
		//when we returned, it means that we found a connected component and we need to increment the number of connected components
		connectedComponents++;
	}
	statistical_results += MString("Number of connected components: ") + connectedComponents + MString("\n");
	// eight row of the statistics table : Number of boundaries
	// find all the boundary edges of the mesh
	MItMeshEdge edge_It(meshFn.object());
	MCHECKERROR(stat, "Can't access mesh edges");

	// save the boundary edges in a set
	std::unordered_set<int> boundaryEdges;
	// iterate over all edges and check if they are boundary edges
	while (!edge_It.isDone())
	{
		if (edge_It.onBoundary())
		{
			// if the edge is a boundary edge, add it to the boundary edges list
			boundaryEdges.insert(edge_It.index());
		}
		edge_It.next();
	}

	// Check for loops in the boundary edges set
	int Boundary_num = 0;
	while (!boundaryEdges.empty())
	{
		int status; //for the setIndex method
		//get first element of the set
		const int first = *boundaryEdges.begin();
		//call the FindLoopInBoundaryEdges method to find the loop in the boundary edges set
		FindLoopInBoundaryEdges(edge_It, boundaryEdges, first);
		//when we returned, it means that we found a loop in the boundary edges set and we need to increment the number of boundaries
		Boundary_num++;
		// each time we return from the FindLoopInBoundaryEdges method, 
		// and the set is not empty, then there is another boundary.
	}

	//update the statistics table
	statistical_results += MString("Number of boundaries: ") + Boundary_num + MString("\n");


	// ninth row of the statistics table : Euler number (formula from slides)
	const int Euler = Vertices - Edges + Faces;
	statistical_results += MString("Euler number: ") + Euler + MString("\n");

	//tenth row of the statistics table : Gauss Bonnet 
	//define a MDoubleArray to store the curvature of each vertex
	MDoubleArray curvature(meshFn.numVertices());
	//get the sum of the curvature of all vertices
	const double sumCurvature = CalcCurvature(meshFn, curvature);
	//calc the gauss bonnet
	const double EulerNum_GaussBonet = sumCurvature / (2 * M_PI);
	//define a buffer to store the result of the gauss bonnet
	char buffer[100] = "";
	//use sprintf to convert the double to string
	sprintf(buffer, "%.15lf", EulerNum_GaussBonet);
	//update the statistics table
	statistical_results += MString("Euler number based on discrete Gauss Bonnet: ") + buffer + MString("\n");


	//Display the statistics table in the script editor
	MGlobal::displayInfo(statistical_results);

	return MS::kSuccess;

}

MSyntax topologyStatisticsCmd::syntax()
{
	MStatus stat = MS::kSuccess;
	MSyntax commandSyntax;


	stat = commandSyntax.setObjectType(MSyntax::kSelectionList, 1, 1); //expect exactly one object
	MCHECKERRORNORET(stat, "Can't create Syntax object for this command");

	commandSyntax.useSelectionAsDefault(true);
	return commandSyntax;
}


void topologyStatisticsCmd::FindLoopInBoundaryEdges(MItMeshEdge& edge_it, std::unordered_set<int>& BoundaryEdgesSet, const int& set_first_indx)
{

	int stat; //for the setIndex method
	//set iterator on the first element of the set
	edge_it.setIndex(set_first_indx, stat);
	//remove the first element of the set
	BoundaryEdgesSet.erase(set_first_indx);

	//get all connected edges of the first element of the set
	MIntArray connectedEdgesIndexes;
	edge_it.getConnectedEdges(connectedEdgesIndexes);

	//iterate over all connected edges of the current edge
	for (const int currentEdge : connectedEdgesIndexes)
	{
		//set iterator on the current edge
		edge_it.setIndex(currentEdge, stat);
		//check if the current edge is in the boundary edges and it is in the set
		// count method returns the number of occurences of the elemnt in the set and 0 if it is not in the set
		if (edge_it.onBoundary() && BoundaryEdgesSet.count(currentEdge))
		{
			//recursive call to the method with the current edge as the first element of the set
			FindLoopInBoundaryEdges(edge_it, BoundaryEdgesSet, currentEdge);
		}
	}
}


double topologyStatisticsCmd::CalcCurvature(const MFnMesh& meshFn, MDoubleArray& curvature)
{
	double angle = 0;
	//This allows us to iterate over the vertices of the mesh
	MItMeshVertex vertex_it(meshFn.object());
	//This array will hold the indices of the vertices we want to color, every index is an integer
	MIntArray vertexList;
	int curIndex;

	// Iterate over the vertices, for boundry vertices we set the angle to pi, for non-boundry vertices we set the angle to 2pi
	while (!vertex_it.isDone())
	{
		curIndex = vertex_it.index();
		// Check if the vertex is on the boundry
		if (vertex_it.onBoundary())
		{
			curvature[curIndex] = M_PI;
		}
		else
		{
			curvature[curIndex] = 2 * M_PI;
		}
		// Go to the next vertex
		vertex_it.next();
	}


	// Create a polygnal iterator
	MItMeshPolygon poly_it(meshFn.object());
	// Iterate over the polygons
	while (!poly_it.isDone())
	{
		// Get the number of vertices in the current polygon
		const int numVertices = poly_it.polygonVertexCount();
		// Create an array to save the indices of the vertices of the current polygon
		MIntArray vertices;
		// Get the indices of the vertices of the current polygon
		poly_it.getVertices(vertices);
		// Create a real-world position of the current vertex
		MPoint p1, p2, p3;
		// Create an array of 3D vectors to save the edges of the current vertex
		MVectorArray poli_vertexs_pos_in_R3 = (3);

		// Set three indexes for the vertices of the current polygon
		int indx1, indx2, indx3;

		// Iterate over the vertices of the current polygon
		for (int i = 0; i < numVertices; i++)
		{
			// Get the indices of the vertices that are on the current polygon
			indx1 = vertices[i];
			indx2 = vertices[(i + 1) % numVertices];
			indx3 = vertices[(i + 2) % numVertices];

			meshFn.getPoint(indx1, p1);
			meshFn.getPoint(indx2, p2);
			meshFn.getPoint(indx3, p3);

			// Save the vertices positions in the array
			poli_vertexs_pos_in_R3[0] = p1;
			poli_vertexs_pos_in_R3[1] = p2;
			poli_vertexs_pos_in_R3[2] = p3;

			// Now we calc the edges of the current vertex by subtracting the position of the current vertex from the position of the next vertex
			MVector edge1 = poli_vertexs_pos_in_R3[1] - poli_vertexs_pos_in_R3[0];
			MVector edge2 = poli_vertexs_pos_in_R3[2] - poli_vertexs_pos_in_R3[0];

			// Calc the angle of the current vertex
			angle = edge1.angle(edge2);

			//Sub the angle of the current poligon from the curvature of the current vertex
			curvature[vertices[i]] -= angle;
		}
		// Go to the next polygon
		poly_it.next();
	}

	//calc the sum of the curvature of all the vertices
	double sum_of_curv = 0;
	for (int i = 0; i < curvature.length(); i++)
	{
		sum_of_curv += curvature[i];
	}

	return sum_of_curv;
}



void topologyStatisticsCmd::FindConnectedComponents(MItMeshVertex& vertix_it, std::unordered_set<int>& VertixIndexSet, const int& set_first_indx)
{
	// set an status variable
	int status;
	// set the iterator on the first element of the set
	vertix_it.setIndex(set_first_indx, status);
	// remove the first element of the set
	VertixIndexSet.erase(set_first_indx);

	//define a array for all connected vertices
	MIntArray connectedVerticesIndexes;
	//get all connected vertices of the first element of the set
	vertix_it.getConnectedVertices(connectedVerticesIndexes);

	//iterate over all connected vertices of the current vertex
	for (const int currentVertex : connectedVerticesIndexes)
	{
		//set iterator on the current vertex
		vertix_it.setIndex(currentVertex, status);
		//check if the current vertex is in the set
		// count method returns the number of occurences of the elemnt in the set and 0 if it is not in the set
		// this condition always true because until we dont delete the element from the set, it is in the set
		if (VertixIndexSet.count(currentVertex))
		{
			//recursive call to the method with the current vertex as the first element of the set
			FindConnectedComponents(vertix_it, VertixIndexSet, currentVertex);
		}
	}
}
