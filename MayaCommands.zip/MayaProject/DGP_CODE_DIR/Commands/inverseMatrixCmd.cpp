//Avidan Menashe
//This code gets a matrix and return its inverse matrix by using the Matlab engine

#include "inverseMatrixCmd.h"

#include "stdafx.h"


#include "Utils/STL_Macros.h"
#include "Utils/Maya_Macros.h"
#include "Utils/Maya_Utils.h"
#include "Utils/MatlabInterface.h"
#include "Utils/GMM_Macros.h"
#include "Utils/MatlabGMMDataExchange.h"
#include "Utils/Utilities.h"

#define Num_of_Args 9
#define Mat_size 3


inverseMatrixCmd::inverseMatrixCmd()
{

}

// This meathod returns a pointer to a new instance of the command.
void* inverseMatrixCmd::creator()
{
	return new inverseMatrixCmd;
}

// This method returns the name of the command.
MString inverseMatrixCmd::commandName()
{
	return "inverseMatrixCmd";
}

bool inverseMatrixCmd::isUndoable() const
{
	return false;
}

MStatus	inverseMatrixCmd::doIt(const MArgList& argList)
{
	MStatus stat = MS::kSuccess;

	// Get arguments from the user using the syntax object
	MSyntax commandSyntax = syntax();
	// Define MArgDatabase object to access the arguments
	MArgDatabase argData(commandSyntax, argList, &stat);
	MCHECKERROR(stat, "Wrong syntax for command " + commandName());


	//Define a matrix to store the arguments
	GMMDenseColMatrix Matrix(Mat_size, Mat_size);
	//Define a variable to store the current argument
	double CurrentArgument;
	//Define a variable to store the current argument index
	int CurrentIndex;

	// Populate the matrix using the arguments provided by the user
	for (int i = 0; i < Mat_size; i++) {
		for (int j = 0; j < Mat_size; j++) {
			// Calculate the current argument index
			CurrentIndex = (i * Mat_size) + j;
			// Get the current argument from argData object and check for errors
			stat = argData.getCommandArgument(CurrentIndex, CurrentArgument);
			MCHECKERROR(stat, "Invalid arg for matrix: arg NO. " + CurrentIndex);
			// Store the current argument in the matrix
			Matrix(i, j) = CurrentArgument;
		}
	}

	//Notify the user about the matrix he provided
	cout << "Matrix Accepted, The Matrix is: " << Matrix << endl;

	// We first will calculate the determinant of the matrix,
	// if the determinant is 0, the matrix is not invertible and we will notify the user about that
	// Note: all calculations will be done using the Matlab engine
	int result_stat = 0;
	GMMDenseColMatrix MatrixDet(1, 1);


	// Call the Matlab engine to calculate the determinant of the matrix
	result_stat = MatlabGMMDataExchange::SetEngineDenseMatrix("Matrix", Matrix);
	// Check for errors
	if (result_stat != 0) {
		MGlobal::displayError("Error in setting the matrix in the Matlab engine");
		return MS::kFailure;
	}

	// Call the Matlab engine to calculate the determinant of the matrix
	MatlabInterface::GetEngine().EvalToCout("MatrixDet = det(Matrix);");
	//Get the result from the Matlab engine
	result_stat = MatlabGMMDataExchange::GetEngineDenseMatrix("MatrixDet", MatrixDet);
	// Check for errors
	if (result_stat != 0) {
		MGlobal::displayError("Error in getting the determinant of the matrix from the Matlab engine");
		return MS::kFailure;
	}


	// Check if the determinant is 0
	if (MatrixDet(0, 0) == 0) {
		MGlobal::displayError("The matrix is not invertible");
		return MS::kFailure;
	}

	// If the determinant is not 0, we will calculate the inverse of the matrix
	GMMDenseColMatrix MatrixInv(Mat_size, Mat_size);
	// Call the Matlab engine to calculate the inverse of the matrix
	MatlabInterface::GetEngine().EvalToCout("MatrixInv = inv(Matrix);");
	//Get the result from the Matlab engine
	result_stat = MatlabGMMDataExchange::GetEngineDenseMatrix("MatrixInv", MatrixInv);
	// Check for errors
	if (result_stat != 0) {
		MGlobal::displayError("Error in getting the inverse of the matrix from the Matlab engine");
		return MS::kFailure;
	}

	//Notify the user about the inverse of the matrix
	cout << "The inverse of the matrix is: " << MatrixInv << endl;
	//MString result = "The inverse of the matrix is: " + MString(MatrixInv);
	//display the invers of the matrix in the Maya script editor
	std::stringstream ss;
	ss << "The inverted matrix: " << endl;
	for (size_t i = 0; i < Mat_size; i++)
	{
		for (rsize_t j = 0; j < Mat_size; j++)
		{
			ss << MatrixInv(i, j) << "\t";
		}
		ss << endl;
	}
	MGlobal::displayInfo(ss.str().c_str());

	return MS::kSuccess;

}

MSyntax inverseMatrixCmd::syntax()
{
	MStatus stat = MS::kSuccess;
	MSyntax commandSyntax;

	//We need to read the arguments send by the user to the command, the arguments will be used to fill the matrix
	for (int i = 0; i < Num_of_Args; i++)
	{
		stat = commandSyntax.addArg(MSyntax::kDouble);
		MCHECKERRORNORET(stat, "Can't create Syntax object for this command");
	}


	stat = commandSyntax.setObjectType(MSyntax::kSelectionList, 1, 1); //expect exactly one object
	MCHECKERRORNORET(stat, "Can't create Syntax object for this command");

	commandSyntax.useSelectionAsDefault(true);
	return commandSyntax;
}

