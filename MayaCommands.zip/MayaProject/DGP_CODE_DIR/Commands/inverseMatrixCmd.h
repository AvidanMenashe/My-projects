//Avidan Menashe
#pragma once
#include "C:\Program Files\Autodesk\Maya2022\include\maya\MPxCommand.h"
class inverseMatrixCmd : public MPxCommand
{
public:
	inverseMatrixCmd();
	virtual MStatus	doIt(const MArgList& argList);
	static void* creator();
	static MSyntax syntax();
	static MString commandName();
	virtual bool isUndoable() const;
};

