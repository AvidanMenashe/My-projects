//Avidan Menashe
//this command creates two sets of colors for the vertices of a triangle mesh.
//The first color set is determined according to the the rank of each vertex.
//The second color set is determined according to the gaussian curvature of each vertex.

#include "stdafx.h"
#include "colorMeshVerticesCmd.h"

#include "Utils/STL_Macros.h"
#include "Utils/Maya_Macros.h"
#include "Utils/Maya_Utils.h"
#include "Utils/MatlabInterface.h"
#include "Utils/GMM_Macros.h"
#include "Utils/MatlabGMMDataExchange.h"
#include <cmath>

//include the header file of the utilities 
#include "Utils/Utilities.h"

//define the flags
#define CurFlagMin  "-min"
#define CurFlagMax  "-max"
#define CurFlagMinLong  "-minimum"
#define CurFlagMaxLong  "-maximum"





//costructor
colorMeshVerticesCmd::colorMeshVerticesCmd()
{

}

//function creat a pointer to new object
void* colorMeshVerticesCmd::creator()
{
	return new colorMeshVerticesCmd;
}

//function return the name of the command
MString colorMeshVerticesCmd::commandName()
{
	return "colorMeshVerticesCmd";
}

//function return flag with false
bool colorMeshVerticesCmd::isUndoable() const
{
	return false;
}

MStatus	colorMeshVerticesCmd::doIt(const MArgList& argList)
{
	MStatus stat = MS::kSuccess;

	MSyntax commandSyntax = syntax();
	MArgDatabase argData(commandSyntax, argList, &stat);
	MCHECKERROR(stat, "Wrong syntax for command " + commandName());

	MSelectionList objectsList;
	stat = argData.getObjects(objectsList);
	MCHECKERROR(stat, "Can't access object list");

	MObject object;
	stat = objectsList.getDependNode(0, object);
	MCHECKERROR(stat, "Can't access object");

	MObject meshObject;
	stat = Maya_Utils::getMe_a_Mesh(object, meshObject);
	MCHECKERROR(stat, "Object is not a mesh");

	MFnMesh meshFn(meshObject, &stat);
	MCHECKERROR(stat, "Can't access mesh");

	int numVerticesInMeshCreated = 0;
	int numPolygons = meshFn.numPolygons(&stat);

	MItMeshPolygon poly(meshObject);
	if(!poly.isPlanar(&stat) || poly.isLamina(&stat) || poly.isHoled(&stat))
	{
		MCHECKERROR(MS::kFailure, "The given polygon shape is either self intersecting, holed or non-planar which are not supported");
	}

	//check if the mesh is a triangle mesh
	unsigned int temp; 
	for (int i=0; i<numPolygons; i++)
	{
		temp=poly.polygonVertexCount();
		if ( 3 != temp )
			MCHECKERROR(MS::kFailure, "this is not a triangle mesh!");
		poly.next();
	}
	
	/***************** valence ****************/
	//delete the color set if it exists
	meshFn.deleteColorSet("Valence");
	meshFn.deleteColorSet("Curvature");
	//create a new color sets
	MString s1 = meshFn.createColorSetWithName("Valence");
	MString s2 = meshFn.createColorSetWithName("Curvature");
	meshFn.setCurrentColorSetName( s1 );

	//this allows us to iterate over the vertices of the mesh
	MItMeshVertex vertex_it(meshFn.object());
	//this is the array we hold the indices of the vertices we want to color
	MIntArray vertexList;
	//this is the array we hold the colors we want to assign to the vertices, each color is a quard of floats
	MColorArray colors;

	int curIndex,degree;

	//isDone() returns true when we reach the end of the iteration
	while ( !vertex_it.isDone() )
	{
		//get the index of the current vertex
		curIndex = vertex_it.index();
		//calcule the degree of the vertex using the method numConnectededges()
		//stat show if the method was successful
		stat=vertex_it.numConnectedEdges(degree);
		MCHECKERROR(stat, "Can't access the number of conected edges is the current vertex");
		switch ( degree )
		{
         //case 0-2 is empty becaue we want to color with the same color the vertex with degree 3
		case 0:
		case 1:
		case 2:
		case 3:
			//we will assign the  vertex with degree 3 color
			colors.append( 0.5f, 0.0f, 1.0f);
		    break;
		case 4:
			//we will assign the  vertex with degree 4 color
			colors.append( 0.0f, 1.0f, 1.0f);
			break;
		case 5:
			//we will assign the  vertex with degree 5 color
			colors.append( 1.0f, 0.0f, 1.0f);
			break;
		case 6:
			//we will assign the  vertex with degree 6 color
			colors.append( 0.0f, 1.0f, 0.0f);
			break;
		case 7:
			//we will assign the  vertex with degree 7 color
			colors.append( 1.0f, 1.0f, 0.5f);
			break;
		case 8:
			//we will assign the  vertex with degree 8 color
			colors.append( 0.0f, 0.0f, 1.0f);
			break;
		default:
			//we will assign the  vertex with other degree  color
			colors.append( 1.0f, 0.0f, 0.0f);
			break;
		}
		vertexList.append( curIndex );
		vertex_it.next();
	}

	//This line sort -of belonging the color of the vertix to the right vertex
	meshFn.setVertexColors ( colors , vertexList );
	//This line display the color of the vertix
	meshFn.setDisplayColors( true );
	/*********************The curvature part****************************/
	//activate the curvature set, so we can see the changes is maya
	meshFn.setCurrentColorSetName( s2 );

	//clear the color and vertex array so we can use them again without wrong data
	colors.clear();
	vertexList.clear();

	//create a MITMeshPolygon to iterate over the polygons
	MItMeshPolygon poly_it(meshFn.object());

	//define a variable to hold the angle value
	double angle;

	//create array to hold the curvature of the vertices
	MDoubleArray curvature(meshFn.numVertices());

	//reset the iterator
	vertex_it.reset();

	//isDone() returns true when we reach the end of the iteration
	while (!vertex_it.isDone())
	{
		curIndex = vertex_it.index();
		//check if the vertex is on the boundary
		if (vertex_it.onBoundary())
		{
			curvature[curIndex] = M_PI;
		}
		
		//the vertex is not on the boundary
		else
		{
			curvature[curIndex] = 2* M_PI;
		}

		//GO to the next vertex
		vertex_it.next();

	}

	//interate over the polygons
	while (!poly_it.isDone())
	{
		//get the number of vertices in the current polygon
		int numVertices = poly_it.polygonVertexCount();

		//create an array to hold the indices of the vertices in the current polygon
		MIntArray vertices;

		//get the indices of the vertices in the current polygon
		poly_it.getVertices(vertices);

		//create a real world possition points (x,y,z)
		MPoint p1, p2, p3;

		//create a array of 3 vectors of 3D
		MVectorArray triangle_vertex_pos= (3);

		//Iterate over the vertices in the current polygon
		for (int i = 0; i < numVertices; i++)
		{
			//get the idices of the vertices in the currnet polyigon
			int index1 = vertices[i];
			int index2 = vertices[(i + 1) % numVertices];
			int index3 = vertices[(i + 2) % numVertices];

			//get the position of the vertices in the currnet polyigon
			meshFn.getPoint(index1, p1);
			meshFn.getPoint(index2, p2);
			meshFn.getPoint(index3, p3);

			//save the vertices position in the array
			triangle_vertex_pos[0] = p1;
			triangle_vertex_pos[1] = p2;
			triangle_vertex_pos[2] = p3;

			//Now we calc the edges of the current vertex
			MVector edge1 = triangle_vertex_pos[1] - triangle_vertex_pos[0];
			MVector edge2 = triangle_vertex_pos[2] - triangle_vertex_pos[0];

			//caculate the angle between the edges
			angle = edge1.angle(edge2);

			//subtract the angle from the curvature of the current vertex
			curvature[vertices[i]] -= angle;
		}
		// go to the next polygon
		poly_it.next();
	}
	
	
	//create a variable to hold the min and max curvature
	double minCurvature = curvature[0];
	double maxCurvature = curvature[0];
	//Calculating default Min and Max curvature
	for (int i = 0; i < curvature.length(); i++)
	{
		//check if the current curvature is smaller than the min curvature
		if (curvature[i] < minCurvature)
		{
			//update the min curvature
			minCurvature = curvature[i];
		}

		//check if the current curvature is bigger than the max curvature
		if (curvature[i] > maxCurvature)
		{
			//update the max curvature
			maxCurvature = curvature[i];
		}
	}

	//check if the min or max flag is set in the command line
	if (argData.isFlagSet(CurFlagMin))
	{
		//get the value of the min flag
		minCurvature=argData.flagArgumentDouble(CurFlagMin, 0, &stat);
		//print error if needed
		MCHECKERRORNORET(stat, "Flag is not accessable"+MString(CurFlagMin));
	}

	if (argData.isFlagSet(CurFlagMax))
	{
		//get the value of the max flag
		maxCurvature=argData.flagArgumentDouble(CurFlagMax, 0, &stat);
		//print error if needed
		MCHECKERRORNORET(stat, "Flag is not accessable"+MString(CurFlagMax));
	}

	//check if the min flag is bigger than the max flag
	if (minCurvature > maxCurvature)
	{
		//print error in Maya
		MGlobal::displayError("The min curvature is bigger than the max curvature");
		//return error
		return MS::kFailure;
	}

	//display the min and max curvature in maya
	//Build the string to display
	MString message = "The minimum curvature value is: ";
	message += minCurvature;
	message += " and the maximum curvature value is: ";
	message += maxCurvature;
	//Display the message in Maya
	MGlobal::displayInfo(message);

	//create a variable to hold the colors of the vertices
	float R, G, B;
	//reset the iterator of the vertices
	vertex_it.reset();

	//isDone() returns true when we reach the end of the iteration
	while (!vertex_it.isDone())
	{
		//Get the index of the current vertex
		curIndex = vertex_it.index();
		//convert the curvature to a color value
		mapColor(curvature[curIndex],R,G,B,minCurvature,maxCurvature);
		//save the triple of color values in the color array
		colors.append(R,G,B);
		//go to the next vertex
		vertex_it.next();
		//append the current vertex index to the vertexlist
		vertexList.append(curIndex);
	}

	//Finally, match the colors to the vertices
	meshFn.setVertexColors(colors, vertexList);
	return MS::kSuccess;
}

MSyntax colorMeshVerticesCmd::syntax()
{
	MStatus stat = MS::kSuccess;
	MSyntax commandSyntax;

	//define which flags are used in the command
	//min flag
	stat=commandSyntax.addFlag(CurFlagMin,CurFlagMinLong, MSyntax::kDouble);
	MCHECKERRORNORET(stat, "Can't create Syntax object for this command");

	//max flag
	stat=commandSyntax.addFlag(CurFlagMax,CurFlagMaxLong, MSyntax::kDouble);
	MCHECKERRORNORET(stat, "Can't create Syntax object for this command");

	stat = commandSyntax.setObjectType(MSyntax::kSelectionList, 1, 1); //expect exactly one object
	MCHECKERRORNORET(stat, "Can't create Syntax object for this command");

	commandSyntax.useSelectionAsDefault(true);
	return commandSyntax;
}
