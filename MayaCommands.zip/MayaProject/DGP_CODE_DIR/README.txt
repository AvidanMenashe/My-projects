In this file, we will explain how to use the commands we wrote:

For each mesh, in the script editor, before running any command, you should select the mesh with the mouse, it will be colored in a light green shade.


1.	colorMeshVerticesCmd (-min) (value) (-max) (value)

This command creates two sets of colors for the vertices of a triangle mesh. The first color set is determined according to the rank of each vertex. The second color set is determined according to the gaussian curvature of each vertex.
if you would like to change between the color sets, you need to select the mesh, click the right mouse button, and choose the color sets option.

in "( )" there are optional flags that can be added by the user if needed.
This command accept only tirangle mesh objects.
"value" represnts a number.

Examples:
	colorMeshVerticesCmd (this will apply deafult settings)
	colorMeshVerticesCmd -min 0 -max 0.1
	colorMeshVerticesCmd - min 0
	colorMeshVerticesCmd -max 0.1
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

2.	inverseMatrixCmd (val) (val) (val) (val) (val) (val) (val) (val) (val)

This code gets a matrix and return its inverse matrix by using the Matlab engine.

in "( )" are the input matrix values 
each 3 arguments presents a row in the input matrix.
If the matrix is not invertable (e.g. detM=0), an error message will be printed to the MAYA screen

Examples:
	inverseMatrixCmd 1 0 0 0 1 0 0 0 1

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
3.	topologyStatisticsCmd
this command works only on a triangular mesh and show the topological characteristics of the mesh, such as, the number of vertices, edges and faces. Also, Euler number, the genus of the mesh, number of connected components and the number of boundaries.

This command accepts only triangle mesh objects.
This command has no input arguments

Examples:
	topologyStatisticsCmd
	
Comments: 
1. The code will not work if the Maya program will not be open. So, I attached some pictures that demonstrate the results of the commands. 
2. The like between the systems, Visualstudio and Maya, were done by Professor Ofir Weber, and all the rights are reserved to him. 
3. It is important to update the environment variables of DGP_CODE_DIR, to the path where you save the project. 

Enjoy!
Avidan Menashe
