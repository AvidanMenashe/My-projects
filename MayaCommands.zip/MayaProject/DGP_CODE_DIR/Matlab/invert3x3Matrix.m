

%You can add your Matlab code here by either defining a Matlab function or a Matlab script.
%Make sure the .m file is located under a folder which is part of Matlab's path.
%You can add a folder to Matlab's path. See this: https://www.mathworks.com/help/matlab/matlab_env/add-remove-or-reorder-folders-on-the-search-path.html

function inv_M = invert3x3Matrix(M)

%add code here
inv_M = inv(M);

end