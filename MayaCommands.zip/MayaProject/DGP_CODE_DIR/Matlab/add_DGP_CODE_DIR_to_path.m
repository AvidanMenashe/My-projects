DGP_dir = getenv('DGP_CODE_DIR');
matlabScriptPath = [DGP_dir, '\Matlab'];
addpath(matlabScriptPath);
savepath;