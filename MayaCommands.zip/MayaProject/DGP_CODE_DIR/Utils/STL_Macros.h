#pragma once


typedef std::complex<double> ComplexDouble;
typedef std::complex<long double> ComplexLongDouble;
typedef std::complex<float> ComplexFloat;
typedef ComplexDouble Complex;
